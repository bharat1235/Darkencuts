import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

export default function Home() {
  const [photos, setPhotos] = useState([]);

  useEffect(() => {
    fetch('/api/drive').then(res => res.json()).then(data => setPhotos(data));
  }, []);

  return (
    <div className="bg-black text-white min-h-screen font-sans">
      <nav className="p-6 flex flex-col items-center border-b border-zinc-900">
        <h1 className="text-3xl font-bold tracking-[0.2em]">DARKENCUTS</h1>
        <p className="text-[10px] text-yellow-500 tracking-[0.4em] uppercase">A Post Production Studio</p>
      </nav>

      <section className="h-[60vh] flex flex-col items-center justify-center text-center px-4">
        <motion.h2 initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-5xl md:text-8xl font-black italic text-zinc-800 uppercase">
          Retouch
        </motion.h2>
        <p className="mt-4 text-zinc-400 tracking-widest uppercase">Every Detail Matters</p>
      </section>

      <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
        {photos.map(photo => (
          <div key={photo.id} className="aspect-[4/5] bg-zinc-900 overflow-hidden group">
            <img src={photo.thumbnailLink?.replace('=s220', '=s1200')} className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition duration-500" />
          </div>
        ))}
      </div>
    </div>
  );
}